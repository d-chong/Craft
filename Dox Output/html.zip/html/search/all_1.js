var searchData=
[
  ['client_1',['Client',['../classbuilder_1_1_client.html',1,'builder']]],
  ['craft_2',['Craft',['../md___users_gavinanderson__documents__c__craft__r_e_a_d_m_e.html',1,'']]]
];
