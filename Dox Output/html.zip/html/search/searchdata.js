var indexSectionsWithContent =
{
  0: "bcfhlmrsw",
  1: "chmrsw",
  2: "bcfls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Pages"
};

